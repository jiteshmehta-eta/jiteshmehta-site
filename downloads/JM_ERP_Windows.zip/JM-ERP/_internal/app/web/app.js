// JM ERP web client. No build step: plain ES module. Every form is generated from the action schema
// the server publishes, so the UI, the REST API and the AI connector always offer the same operations.
const $app = document.getElementById("app"), $modal = document.getElementById("modal-root"), $toasts = document.getElementById("toasts");
const store = { get token() { try { return localStorage.getItem("jmeta_token"); } catch { return null; } },
  set token(v) { try { v ? localStorage.setItem("jmeta_token", v) : localStorage.removeItem("jmeta_token"); } catch { } } };
let META = null, PUBLIC = null, assistOpen = false, chat = [];

// ───────── helpers ─────────
function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (k === "class") e.className = v;
    else if (k === "html") e.innerHTML = v;
    else if (k in e && k !== "list") e[k] = v; else e.setAttribute(k, v);
  }
  for (const k of kids.flat(9)) if (k != null && k !== false) e.append(k.nodeType ? k : document.createTextNode(String(k)));
  return e;
}
async function api(path, opts = {}) {
  const r = await fetch(path, { method: opts.method || (opts.body ? "POST" : "GET"),
    headers: { "Content-Type": "application/json", ...(store.token ? { Authorization: "Bearer " + store.token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined });
  if (r.status === 401) { store.token = null; META = null; renderLogin(); throw new Error("Please sign in."); }
  const ct = r.headers.get("content-type") || "";
  const data = ct.includes("json") ? await r.json() : await r.text();
  if (!r.ok) throw new Error((data && data.error) || (data && data.detail && JSON.stringify(data.detail)) || "Request failed");
  return data;
}
function toast(msg, bad) {
  const t = h("div", { class: "toast" + (bad ? " bad" : "") }, msg);
  $toasts.append(t); setTimeout(() => t.remove(), bad ? 9000 : 6000);
}
const fmt = v => v == null || v === "" ? "" : typeof v === "number" ? v.toLocaleString(undefined, { maximumFractionDigits: 2 }) : typeof v === "boolean" ? (v ? "Yes" : "No") : String(v);
const OK = ["approved", "active", "posted", "paid", "received", "completed", "verified", "released", "awarded", "confirmed", "closed", "accepted", "ratified", "done", "issued_ok", "returned", "declared", "ordered", "qualified", "on target"];
const BAD = ["rejected", "blocked", "cancelled", "suspended", "removed", "overdue", "expired", "disqualified", "refused", "terminated", "below target", "mismatch"];
const WARN = ["pending", "draft", "inspection", "awaiting_callback", "awaiting_finance", "partially_received", "partially_issued", "recommended", "escalated", "counting", "applicant", "prequalifying", "proposed", "open", "on_loan", "quarantine", "ready", "submitted", "tech_eval"];
function chip(s) {
  if (s == null || s === "") return "";
  const k = String(s).toLowerCase();
  const c = OK.includes(k) ? "ok" : BAD.includes(k) ? "bad" : WARN.includes(k) ? "warn" : "";
  return h("span", { class: "chip " + c }, String(s).replace(/_/g, " "));
}
const isStatusCol = l => /^(status|line status|pr status|result|stock type|match|alert)$/i.test(l);
function go(hash) { if (location.hash === hash) route(); else location.hash = hash; }
function table(cols, rows, onRow) {
  if (!rows.length) return h("div", { class: "empty" }, "Nothing to show yet.");
  const numeric = cols.map((_, i) => rows.every(r => r[i] == null || r[i] === "" || typeof r[i] === "number") && rows.some(r => typeof r[i] === "number"));
  return h("div", { class: "tablewrap" }, h("table", {},
    h("thead", {}, h("tr", {}, cols.map((c, i) => h("th", { class: numeric[i] ? "num" : "" }, c)))),
    h("tbody", {}, rows.map((r, n) => h("tr", { class: onRow ? "click" : "", onclick: onRow ? () => onRow(n) : null },
      r.map((v, i) => h("td", { class: numeric[i] ? "num" : "" }, isStatusCol(cols[i]) ? chip(v) : fmt(v))))))));
}

// ───────── login ─────────
async function renderLogin() {
  PUBLIC = PUBLIC || await fetch("/api/public").then(r => r.json());
  document.title = PUBLIC.app;
  const u = h("input", { type: "text", placeholder: "User name", autocomplete: "username" });
  const p = h("input", { type: "password", placeholder: "Password", autocomplete: "current-password" });
  const err = h("div", {});
  const submit = async ev => {
    ev.preventDefault();
    try { const r = await api("/api/login", { body: { username: u.value, password: p.value } }); store.token = r.token; await boot(); }
    catch (e) { err.replaceChildren(h("div", { class: "err", style: "margin:12px 0 0" }, e.message)); }
  };
  $app.replaceChildren(h("div", { class: "login" },
    h("div", { class: "hero" }, h("img", { src: "/static/logo.webp", alt: "JM logo" }), h("h1", {}, PUBLIC.app),
      h("div", { class: "full" }, PUBLIC.full_name), h("div", { class: "by" }, PUBLIC.developed),
      h("div", { class: "tag" }, "Integrated supply chain: cataloguing, sourcing, contracts, procurement, warehouse, invoicing. Operable by people and AI agents alike."),
      h("div", { class: "tag", style: "font-size:12px;margin-top:18px" }, PUBLIC.notice)),
    h("div", { class: "panel" }, h("h2", {}, "Sign in"), h("div", { class: "sub" }, PUBLIC.company),
      h("form", { onsubmit: submit, class: "grid", style: "grid-template-columns:1fr" },
        h("div", { class: "fld" }, h("label", {}, "User"), u), h("div", { class: "fld" }, h("label", {}, "Password"), p),
        h("button", { class: "btn primary", type: "submit" }, "Log on"), err),
      PUBLIC.demo_users.length ? h("div", { class: "demo" }, h("b", {}, "Demo users"),
        h("small", {}, "Click a user to fill the name. The demo password is in README.md. Each role sees its own launchpad."),
        h("div", { class: "list" }, PUBLIC.demo_users.map(d => h("button", { type: "button", onclick: () => { u.value = d.username; p.focus(); } },
          h("b", {}, d.username), " – ", d.name, h("small", {}, d.roles))))) : null)));
}

// ───────── shell ─────────
function shell(content) {
  const m = META, cmd = h("input", { type: "text", placeholder: "T-code (ME21N, MIGO, MIRO ...), document number or search   [Ctrl+K]", id: "cmd", autocomplete: "off" });
  const drop = h("div", { class: "drop", style: "display:none" });
  let timer, opts = [], sel = 0;
  const show = () => { drop.style.display = opts.length ? "" : "none";
    drop.replaceChildren(...opts.map((o, i) => h("div", { class: "opt" + (i === sel ? " sel" : ""), onmousedown: e => { e.preventDefault(); pick(o); } }, o.code ? h("code", {}, o.code) : null, h("span", {}, o.label), h("small", {}, o.type || "")))); };
  const pick = o => { cmd.value = ""; opts = []; show(); cmd.blur(); o.run(); };
  const tcTarget = t => () => openTarget(t);
  cmd.addEventListener("input", () => {
    clearTimeout(timer);
    const raw = cmd.value.trim(), q = raw.replace(/^\/[no]/i, "").toUpperCase();
    opts = []; sel = 0;
    if (!raw) return show();
    for (const [code, t] of Object.entries(m.tcodes)) if (code.startsWith(q)) opts.push({ code, label: t.title, type: "transaction", run: tcTarget(t) });
    opts.sort((a, z) => (z.code === q) - (a.code === q) || a.code.length - z.code.length);   // exact code first
    opts = opts.slice(0, 8);
    for (const g of m.launchpad) for (const t of g.tiles) if (t.title.toUpperCase().includes(q) && opts.length < 14) opts.push({ label: t.title, type: g.group, run: tcTarget(t.target) });
    show();
    if (raw.length >= 2) timer = setTimeout(async () => {
      try { const r = await api("/api/search?q=" + encodeURIComponent(raw));
        if (cmd.value.trim() !== raw) return;
        opts = opts.concat(r.results.map(x => ({ label: x.label, type: x.type, run: () => go(`#/doc/${x.entity}/${x.id}`) }))); show(); } catch { }
    }, 250);
  });
  cmd.addEventListener("keydown", e => {
    if (e.key === "ArrowDown") { sel = Math.min(sel + 1, opts.length - 1); show(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { sel = Math.max(sel - 1, 0); show(); e.preventDefault(); }
    else if (e.key === "Enter" && opts[sel]) pick(opts[sel]);
    else if (e.key === "Enter") toast(`Nothing found for "${cmd.value}".`, true);
    else if (e.key === "Escape") { opts = []; show(); cmd.blur(); }
  });
  cmd.addEventListener("blur", () => setTimeout(() => { opts = []; show(); }, 150));
  const inboxBtn = h("button", { class: "tbtn", onclick: () => go("#/inbox"), title: "My Inbox (SBWP)" }, "Inbox", h("span", { class: "badge", id: "inbox-n", style: "display:none" }));
  const top = h("div", { class: "top" },
    h("div", { class: "brand", onclick: () => go("#/home"), title: "Home" }, h("img", { src: "/static/logo.webp", alt: "" }),
      h("div", {}, h("b", {}, m.app.name), h("span", {}, m.app.full_name), h("span", {}, h("i", {}, m.app.developed)))),
    h("div", { class: "cmd" }, cmd, drop), h("div", { class: "sp" }), inboxBtn,
    m.user.actor !== "supplier" ? h("button", { class: "tbtn", onclick: () => { assistOpen = !assistOpen; route(); } }, "AI Assistant") : null,
    h("button", { class: "tbtn", title: "Illustrated user guide", onclick: () => window.open("/guide/User-Guide.html", "_blank") }, "Help"),
    h("button", { class: "tbtn", title: "Light / dark", onclick: toggleTheme }, "◐"),
    h("div", { class: "who" }, m.user.name, h("small", { title: m.user.roles.join(", ") }, m.user.actor === "supplier" ? "Supplier portal" : m.user.roles.join(", ") || m.user.department)),
    h("button", { class: "tbtn", onclick: () => { store.token = null; META = null; chat = []; location.hash = ""; renderLogin(); } }, "Log off"));
  const sig = h("footer", { class: "sig", title: m.app.notice }, `${m.app.name} ${m.app.full_name} \u00B7 `, h("b", {}, m.app.developed), " \u00B7 \u00A9 2026 \u00B7 ",
    h("a", { onclick: () => alert(m.app.notice) }, "Licence"));
  $app.replaceChildren(top, h("div", { class: "layout" }, h("main", {}, content, sig), assistOpen ? assistant() : null));
  refreshBadge();
}
async function refreshBadge() {
  try { const r = await api("/api/inbox"); const n = r.approvals.length + r.notifications.length; const b = document.getElementById("inbox-n");
    if (b) { b.textContent = n; b.style.display = n ? "" : "none"; } } catch { }
}
function toggleTheme() {
  const d = document.documentElement, t = d.dataset.theme === "dark" ? "light" : "dark"; d.dataset.theme = t;
  try { localStorage.setItem("jmeta_theme", t); } catch { }
}
function openTarget(t) {
  if (t.type === "list") go(`#/list/${t.entity}${t.status ? "?status=" + t.status : ""}`);
  else if (t.type === "action") openAction(t.action);
  else if (t.type === "report") go(`#/report/${t.report}`);
  else if (t.view === "inbox") go("#/inbox");
  else if (t.view === "tree") go("#/tree");
  else if (t.view === "assistant") { assistOpen = true; route(); }
}

// ───────── views ─────────
function viewHome() {
  const m = META, id = g => "g-" + g.replace(/\W+/g, "-");
  shell(h("div", {},
    h("div", { class: "phead" }, h("h1", {}, `Welcome, ${m.user.name.split(" ")[0]}`), h("span", { class: "crumb" }, `${m.app.company}${m.user.bu ? " · " + m.user.bu : ""} · Type a transaction code in the bar above, or pick a tile.`)),
    h("div", { class: "gnav" }, m.launchpad.map(g => h("a", { onclick: () => document.getElementById(id(g.group)).scrollIntoView({ behavior: "smooth", block: "start" }) }, g.group))),
    m.launchpad.map(g => h("section", { class: "group", id: id(g.group) }, h("h2", {}, g.group),
      h("div", { class: "tiles" }, g.tiles.map(t => h("button", { class: "tile", onclick: () => openTarget(t.target) },
        h("b", {}, t.title), t.sub ? h("small", {}, t.sub) : null,
        h("div", { class: "foot" }, h("span", { class: "kind" }, { list: "LIST", action: "CREATE", report: "REPORT", view: "OPEN" }[t.target.type]), t.tcode ? h("code", {}, t.tcode) : null))))))));
}

async function viewList(entity, params) {
  const e = META.entities[entity];
  if (!e) return shell(h("div", { class: "empty" }, "This list is not available for your role."));
  const status = params.get("status") || "";
  const body = h("div", { class: "card" }, h("div", { class: "empty" }, "Loading…"));
  const search = h("input", { type: "search", placeholder: "Search…" });
  const creates = Object.values(META.actions).filter(a => a.entity === entity && a.on === "collection");
  const load = async () => {
    const r = await api(`/api/list/${entity}?q=${encodeURIComponent(search.value)}&status=${status}`);
    const cols = r.columns.map(c => c[1]);
    const csv = () => download(`${entity}.csv`, [cols, ...r.rows.map(row => r.columns.map(c => row[c[0]]))]);
    body.replaceChildren(table(cols, r.rows.map(row => r.columns.map(c => row[c[0]])), n => go(`#/doc/${entity}/${r.rows[n].id}`)),
      h("div", { class: "body toolbar" }, h("small", {}, `${r.rows.length} entr${r.rows.length === 1 ? "y" : "ies"}`), h("button", { class: "btn small", onclick: csv }, "Export CSV")));
  };
  let t; search.addEventListener("input", () => { clearTimeout(t); t = setTimeout(load, 250); });
  shell(h("div", {}, h("div", { class: "phead" }, h("span", { class: "crumb" }, h("a", { onclick: () => go("#/home") }, "Home"), " / ", e.title),
    h("h1", {}, e.title, status ? " – " + status : ""), h("div", { class: "sp", style: "flex:1" }),
    h("div", { class: "toolbar" }, search, creates.map(a => h("button", { class: "btn primary", onclick: () => openAction(a.name) }, a.title)))), body));
  load().catch(err => body.replaceChildren(h("div", { class: "empty" }, err.message)));
}

let liveTimer = null;
async function viewDoc(entity, id) {
  let d;
  clearTimeout(liveTimer);
  try { d = await api(`/api/doc/${entity}/${id}`); } catch (e) { return shell(h("div", { class: "empty" }, e.message)); }
  if (/auction$/.test(entity) && (d.status === "live" || d.status === "scheduled")) {   // live bidding: refresh every 4 s
    const here = location.hash;
    liveTimer = setTimeout(() => { if (location.hash === here && !$modal.childElementCount) viewDoc(entity, id); else if (location.hash === here) liveTimer = setTimeout(() => route(), 4000); }, 4000);
  }
  const act = a => h("button", { class: "btn" + (a.danger ? " danger" : " primary"), title: a.human_only ? "Human only" : "", onclick: () => openAction(a.name, { id: d.id }) }, a.title);
  const decide = (a, decision) => async () => {
    if (decision === "reject") return openAction("approval.decide", null, { approval_id: a.id, decision: "reject" });
    try { const r = await api("/api/actions/approval.decide", { body: { approval_id: a.id, decision } }); toast(r.message); route(); } catch (e) { toast(e.message, true); }
  };
  shell(h("div", {},
    h("div", { class: "phead" },
      h("span", { class: "crumb" }, h("a", { onclick: () => go("#/home") }, "Home"), " / ", h("a", { onclick: () => go(`#/list/${entity}`) }, d.entity_title), " / ", d.no),
      h("h1", {}, d.no), chip(d.status), liveTimer && d.status === "live" ? h("span", { class: "chip ok" }, "\u25CF updating live") : null,
      h("span", { style: "color:var(--muted)" }, d.title), h("div", { style: "flex:1" }),
      h("div", { class: "toolbar" }, d.actions.map(act), d.printable ? h("button", { class: "btn", onclick: () => printDoc(entity, id) }, "Print / PDF") : null)),
    d.flags.map(f => h("div", { class: "strip" + (/BLOCK|not |cannot|missing|expired|excluded/i.test(f) ? " bad" : "") }, f)),
    d.flow.length > 1 ? h("div", { class: "card" }, h("h3", {}, "Document flow"), h("div", { class: "body flow" },
      d.flow.map((f, i) => [i ? h("span", { class: "arr" }, "→") : null, h("div", { class: "node" + (f.entity === entity && f.id === d.id ? " cur" : ""), onclick: () => go(`#/doc/${f.entity}/${f.id}`) }, f.no, h("small", {}, `${f.label}${f.status ? " · " + String(f.status).replace(/_/g, " ") : ""}`))]))) : null,
    d.approvals.length ? h("div", { class: "card" }, h("h3", {}, "Approvals (Delegation of Authority)"),
      h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Step", "Approver", "Status", "Decided by", "When", "Comment", ""].map(c => h("th", {}, c)))),
        h("tbody", {}, d.approvals.map(a => h("tr", {}, h("td", {}, a.step), h("td", {}, a.role), h("td", {}, chip(a.status)), h("td", {}, a.by), h("td", {}, a.at), h("td", {}, a.comment || a.note),
          h("td", {}, a.mine ? [h("button", { class: "btn small ok", onclick: decide(a, "approve") }, "Approve"), " ", h("button", { class: "btn small danger", onclick: decide(a, "reject") }, "Reject")] : ""))))))) : null,
    h("div", { class: "card" }, h("h3", {}, "General data"), h("div", { class: "body fields" }, d.fields.filter(f => f[1] !== "" && f[1] != null).map(f => h("div", {}, h("small", {}, f[0]), h("span", {}, isStatusCol(f[0]) ? chip(f[1]) : fmt(f[1])))))),
    d.sections.filter(s => s.rows.length).map(s => h("div", { class: "card" }, h("h3", {}, s.title), table(s.columns, s.rows))),
    d.history && d.history.length ? h("div", { class: "card" }, h("h3", {}, "Change history (audit trail)"),
      table(["When", "User", "Actor", "Action", "Result", "Note"], d.history.map(x => [x.ts, x.user, x.actor, x.action, x.ok ? "done" : "refused", x.note]))) : null));
}

async function viewInbox() {
  const r = await api("/api/inbox");
  const decide = (a, decision) => async () => {
    if (decision === "reject") return openAction("approval.decide", null, { approval_id: a.id, decision: "reject" });
    try { const x = await api("/api/actions/approval.decide", { body: { approval_id: a.id, decision } }); toast(x.message); route(); } catch (e) { toast(e.message, true); }
  };
  const dismiss = async ids => { await api("/api/inbox/read", { body: { ids } }); route(); };
  shell(h("div", {}, h("div", { class: "phead" }, h("span", { class: "crumb" }, h("a", { onclick: () => go("#/home") }, "Home"), " / My Inbox"), h("h1", {}, "My Inbox")),
    h("div", { class: "card" }, h("h3", {}, `Waiting for my approval (${r.approvals.length})`),
      r.approvals.length ? h("div", { class: "tablewrap" }, h("table", {}, h("thead", {}, h("tr", {}, ["Document", "Subject", "Value", "BU", "As", "From", "Since", "Note", ""].map(c => h("th", {}, c)))),
        h("tbody", {}, r.approvals.map(a => h("tr", {}, h("td", {}, h("a", { onclick: () => go(`#/doc/${a.entity}/${a.doc_id}`) }, a.doc_no)), h("td", {}, a.title), h("td", { class: "num" }, fmt(a.value)), h("td", {}, a.bu), h("td", {}, a.role), h("td", {}, a.submitted_by), h("td", {}, a.since), h("td", { style: "max-width:320px" }, a.note),
          h("td", { style: "white-space:nowrap" }, h("button", { class: "btn small ok", onclick: decide(a, "approve") }, "Approve"), " ", h("button", { class: "btn small danger", onclick: decide(a, "reject") }, "Reject"))))))) : h("div", { class: "empty" }, "No approvals are waiting for you.")),
    h("div", { class: "card" }, h("h3", { style: "display:flex;align-items:center;gap:10px" }, `Alerts (${r.notifications.length})`, r.notifications.length ? h("button", { class: "btn small", onclick: () => dismiss(r.notifications.map(n => n.id)) }, "Mark all read") : null),
      r.notifications.length ? h("div", { class: "tablewrap" }, h("table", {}, h("tbody", {}, r.notifications.map(n => h("tr", {}, h("td", { style: "white-space:nowrap;color:var(--muted)" }, n.at), h("td", {}, n.entity && n.entity_id && META.entities[n.entity] ? h("a", { onclick: () => go(`#/doc/${n.entity}/${n.entity_id}`) }, n.text) : n.text),
        h("td", {}, h("button", { class: "btn small", onclick: () => dismiss([n.id]) }, "Done"))))))) : h("div", { class: "empty" }, "No new alerts."))));
}

async function viewReport(name) {
  let r;
  try { r = await api(`/api/reports/${name}`); } catch (e) { return shell(h("div", { class: "empty" }, e.message)); }
  shell(h("div", {}, h("div", { class: "phead" }, h("span", { class: "crumb" }, h("a", { onclick: () => go("#/home") }, "Home"), " / Reports"), h("h1", {}, r.title), h("div", { style: "flex:1" }),
    h("div", { class: "toolbar" }, h("button", { class: "btn", onclick: () => download(`${name}.csv`, [r.columns, ...r.rows]) }, "Export CSV"), h("button", { class: "btn", onclick: () => window.print() }, "Print"))),
    r.kpis.length ? h("div", { class: "kpis" }, r.kpis.map(k => h("div", { class: "kpi" + (k.ok === false ? " bad" : k.ok === true ? " ok" : "") }, h("b", {}, fmt(k.value)), h("small", {}, k.label)))) : null,
    h("div", { class: "card" }, table(r.columns, r.rows))));
}
// asset hierarchy: plant > system > equipment > assembly > spare part, with live stock from the material master
async function viewTree() {
  const t = await api("/api/eam/tree");
  const filter = h("input", { type: "search", placeholder: "Filter by tag, item code or text\u2026" });
  const host = h("div", { class: "tree" });
  const stockChip = s => !s ? null : h("span", { class: "chip " + (s.state.startsWith("SHORT") ? "bad" : s.state.startsWith("not") ? "mute" : "ok"), title: `Min ${s.min} / Max ${s.max} \u00B7 lead time ${s.lead_time_days} days` },
    `stock ${fmt(s.on_hand)} ${s.uom}` + (s.on_order ? ` \u00B7 ${fmt(s.on_order)} on order` : "") + (s.state.startsWith("SHORT") ? " \u00B7 SHORT" : s.state.startsWith("not") ? " \u00B7 not stocked" : ""));
  const match = (n, q) => !q || (n.label + " " + n.sub).toLowerCase().includes(q) || (n.children || []).some(c => match(c, q));
  const node = (n, depth, q) => {
    if (!match(n, q)) return null;
    const kids = (n.children || []).map(c => node(c, depth + 1, q)).filter(Boolean);
    const open = !!q || depth < 3;
    const box = h("div", { class: "tkids", style: open ? "" : "display:none" }, kids);
    const tw = h("span", { class: "tw" }, kids.length ? (open ? "\u25BE" : "\u25B8") : "\u00B7");
    const row = h("div", { class: "trow k-" + n.kind.replace(/\W+/g, "-") },
      tw, h("span", { class: "tkind" }, n.kind), n.entity ? h("a", { onclick: e => { e.stopPropagation(); go(`#/doc/${n.entity}/${n.id}`); } }, n.label) : h("b", {}, n.label),
      n.sub ? h("small", {}, n.sub) : null, stockChip(n.stock));
    if (kids.length) row.addEventListener("click", () => { const sh = box.style.display === "none"; box.style.display = sh ? "" : "none"; tw.textContent = sh ? "\u25BE" : "\u25B8"; });
    return h("div", { class: "tnode" }, row, box);
  };
  const draw = () => host.replaceChildren(...t.roots.map(r => node(r, 0, filter.value.trim().toLowerCase())).filter(Boolean));
  filter.addEventListener("input", draw);
  const all = show => host.querySelectorAll(".tkids").forEach(k => { k.style.display = show ? "" : "none"; k.previousSibling.querySelector(".tw").textContent = k.childElementCount ? (show ? "\u25BE" : "\u25B8") : "\u00B7"; });
  shell(h("div", {}, h("div", { class: "phead" }, h("span", { class: "crumb" }, h("a", { onclick: () => go("#/home") }, "Home"), " / Maintenance / Asset Hierarchy"),
    h("h1", {}, "Asset Hierarchy"), h("div", { style: "flex:1" }),
    h("div", { class: "toolbar" }, filter, h("button", { class: "btn", onclick: () => all(true) }, "Expand all"), h("button", { class: "btn", onclick: () => all(false) }, "Collapse all"), h("button", { class: "btn", onclick: () => window.print() }, "Print"))),
    h("div", { class: "kpis" }, h("div", { class: "kpi" }, h("b", {}, t.totals.equipment), h("small", {}, "Equipment")), h("div", { class: "kpi" }, h("b", {}, t.totals.spares), h("small", {}, "Spare part positions")),
      h("div", { class: "kpi " + (t.totals.short ? "bad" : "ok") }, h("b", {}, t.totals.short), h("small", {}, "Positions short of stock"))),
    h("div", { class: "card" }, h("div", { class: "body" }, host))));
  draw();
}
function download(name, rows) {
  const csv = rows.map(r => r.map(v => `"${String(v ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const a = h("a", { href: URL.createObjectURL(new Blob(["﻿" + csv], { type: "text/csv" })), download: name });
  document.body.append(a); a.click(); a.remove();
}
async function printDoc(entity, id) {
  try { const html = await api(`/api/print/${entity}/${id}`); const w = window.open("", "_blank");
    if (!w) return toast("Allow pop-ups to print.", true); w.document.write(html); w.document.close(); } catch (e) { toast(e.message, true); }
}

// ───────── schema-driven action form ─────────
const unwrap = p => { if (p.anyOf) { const real = p.anyOf.find(x => x.type !== "null") || {}; return { ...p, ...real, anyOf: undefined, nullable: true }; } return p; };
function lookup(ref, value, onChange, multi) {
  let picked = multi ? [...(value || [])].map(id => ({ id, label: "#" + id })) : (value != null ? [{ id: value, label: "#" + value }] : []);
  const chips = h("div", { class: "picked" }), input = h("input", { type: "text", placeholder: `Search ${META.entities[ref] ? META.entities[ref].title.toLowerCase() : ref}… (F4)` }), drop = h("div", { class: "drop", style: "display:none" });
  const emit = () => onChange(multi ? picked.map(p => p.id) : (picked[0] ? picked[0].id : null));
  const draw = () => { chips.replaceChildren(...picked.map(p => h("span", { title: "Click to remove", onclick: () => { picked = picked.filter(x => x !== p); draw(); emit(); } }, p.label + " ×")));
    input.style.display = !multi && picked.length ? "none" : ""; };
  picked.forEach(async p => { try { const r = await api(`/api/label/${ref}/${p.id}`); p.label = r.label; draw(); } catch { } });
  let t;
  const search = () => { clearTimeout(t); t = setTimeout(async () => {
    try { const r = await api(`/api/list/${ref}?limit=25&q=${encodeURIComponent(input.value)}`);
      drop.replaceChildren(...r.rows.map(row => h("div", { class: "opt", onmousedown: e => { e.preventDefault(); if (!picked.some(p => p.id === row.id)) picked = multi ? [...picked, { id: row.id, label: row._label }] : [{ id: row.id, label: row._label }]; input.value = ""; drop.style.display = "none"; draw(); emit(); } }, row._label)));
      if (!r.rows.length) drop.replaceChildren(h("div", { class: "opt" }, "No match"));
      drop.style.display = ""; } catch { } }, 180); };
  input.addEventListener("input", search); input.addEventListener("focus", search);
  input.addEventListener("keydown", e => { if (e.key === "F4") { e.preventDefault(); search(); } });
  input.addEventListener("blur", () => setTimeout(() => drop.style.display = "none", 150));
  draw();
  return h("div", { class: "lookup" }, chips, input, drop);
}
function control(p0, value, set, compact) {
  const p = unwrap(p0);
  if (p.ref && p.type === "array") return lookup(p.ref, value, set, true);
  if (p.ref) return lookup(p.ref, value, set, false);
  if (p.enum) { const s = h("select", { onchange: () => set(p.type === "integer" || p.type === "number" ? Number(s.value) : s.value) },
      (p.nullable || !p.enum.includes(value)) && value == null ? h("option", { value: "" }, "") : null,
      p.enum.map(o => h("option", { value: o, selected: o === value }, o === "" ? "(none)" : String(o).replace(/_/g, " "))));
    if (value == null && !p.nullable && p.enum.length) set(p.enum[0]); return s; }
  if (p.type === "boolean") return h("input", { type: "checkbox", checked: !!value, onchange: e => set(e.target.checked) });
  if (p.type === "integer" || p.type === "number") return h("input", { type: "number", step: "any", value: value ?? "", oninput: e => set(e.target.value === "" ? null : Number(e.target.value)) });
  if (p.type === "array") return h("input", { type: "text", value: (value || []).join(", "), placeholder: "comma separated", oninput: e => set(e.target.value.split(",").map(s => s.trim()).filter(Boolean)) });
  if (p.format === "date") return h("input", { type: "date", value: value ?? "", oninput: e => set(e.target.value || null) });
  if (p.format === "date-time") return h("input", { type: "datetime-local", value: value ? String(value).slice(0, 16) : "", oninput: e => set(e.target.value || null) });
  if (p.widget === "textarea" && !compact) return h("textarea", { oninput: e => set(e.target.value) }, value ?? "");
  return h("input", { type: p.widget === "password" ? "password" : "text", value: value ?? "", oninput: e => set(e.target.value) });
}
function buildFields(schema, data, labels, hook) {
  const req = schema.required || [], out = [];
  for (const [key, p0] of Object.entries(schema.properties || {})) {
    if (key === "id" || key === "approval_id") continue;
    const p = unwrap(p0), title = p.title || key, star = req.includes(key) ? h("span", { class: "req" }, " *") : null;
    if (data[key] === undefined && p.default !== undefined) data[key] = structuredClone(p.default);
    const items = p.items ? unwrap(p.items) : null;
    if (p.type === "array" && items && items.type === "object") {           // line table
      data[key] = data[key] || [];
      const cols = Object.entries(items.properties), tbody = h("tbody", {});
      const addRow = row => { if (!data[key].includes(row)) data[key].push(row);
        const tr = h("tr", {}, cols.map(([ck, cp]) => { const u = unwrap(cp); if (row[ck] === undefined && u.default !== undefined) row[ck] = u.default;
          return h("td", { class: "cell" + (u.ref ? " ref" : "") }, control(cp, row[ck], v => row[ck] = v, true)); }),
          h("td", { class: "x" }, h("button", { type: "button", class: "btn small danger", title: "Remove line", onclick: () => { data[key].splice(data[key].indexOf(row), 1); tr.remove(); } }, "×")));
        tbody.append(tr); };
      data[key].forEach(addRow);
      if (!data[key].length && req.includes(key)) addRow({});
      out.push(h("div", { class: "lines" }, h("div", { class: "lt" }, title, star, h("button", { type: "button", class: "btn small", onclick: () => addRow({}) }, "+ Add line")),
        h("table", {}, h("thead", {}, h("tr", {}, cols.map(([ck, cp]) => h("th", {}, unwrap(cp).title || ck, (items.required || []).includes(ck) ? h("span", { class: "req" }, " *") : null)), h("th", {}))), tbody)));
    } else if (p.type === "object" && p.properties) {                         // nested object
      data[key] = data[key] || {};
      out.push(h("div", { class: "sub" }, h("b", {}, title), h("div", { class: "grid" }, buildFields(p, data[key], {}))));
    } else if (p.type === "object") {                                         // dictionary (e.g. price per line)
      data[key] = data[key] || {};
      const lab = (labels && labels[key]) || {}, keys = Object.keys({ ...lab, ...data[key] });
      out.push(h("div", { class: "sub" }, h("b", {}, title, star), keys.length ? h("div", { class: "grid" }, keys.map(k => h("div", { class: "fld" }, h("label", {}, lab[k] || k),
        h("input", { type: "number", step: "any", value: data[key][k] ?? "", oninput: e => { if (e.target.value === "") delete data[key][k]; else data[key][k] = Number(e.target.value); } }))))
        : h("small", { class: "help" }, "No entries required.")));
    } else if (p.type === "boolean") {
      const c = control(p0, data[key], v => data[key] = v); c.id = "f_" + key + Math.random().toString(36).slice(2, 6);
      out.push(h("div", { class: "fld check" }, c, h("label", { for: c.id }, title)));
    } else {
      out.push(h("div", { class: "fld" + (p.widget === "textarea" ? " wide" : "") }, h("label", {}, title, star), control(p0, data[key], v => { data[key] = v; if (hook) hook(key, v); }), p.help ? h("small", { class: "help" }, p.help) : null));
    }
  }
  return out;
}
function clean(v) {
  if (Array.isArray(v)) return v.map(clean);
  if (v && typeof v === "object") { const o = {}; for (const [k, x] of Object.entries(v)) { if (k.startsWith("_")) continue; const c = clean(x); if (c !== null && c !== undefined && c !== "") o[k] = c; else if (c === "") o[k] = c; } return o; }
  return v;
}
async function openAction(name, ctxDoc, preset) {
  const a = META.actions[name];
  if (!a) return toast("This transaction is not available for your role.", true);
  let data = { ...(preset || {}) }, labels = {};
  if (ctxDoc && ctxDoc.id != null) data.id = ctxDoc.id;
  if (a.has_prefill && data.id != null) { try { const pre = await api(`/api/actions/${name}/prefill?id=${data.id}`); labels = pre._labels || {}; data = { ...pre, ...data }; } catch { } }
  const close = () => $modal.replaceChildren();
  const err = h("div", {});
  const form = h("form", {}), busy = h("small", { style: "color:var(--muted)" });
  // copy-from: when the reference document of a prefill-able create action is chosen (e.g. the PO for a goods
  // receipt or invoice), its open lines are pulled into the form.
  const refKey = a.has_prefill && a.on === "collection" ? Object.keys(a.schema.properties)[0] : null;
  const hook = async (key, v) => { if (key !== refKey || v == null) return;
    try { const pre = await api(`/api/actions/${name}/prefill?id=${v}`); labels = pre._labels || {}; data = { ...data, ...pre }; draw(); } catch { } };
  const draw = () => form.replaceChildren(h("div", { class: "grid" }, buildFields(a.schema, data, labels, hook)));
  draw();
  const submit = async ev => {
    ev && ev.preventDefault(); busy.textContent = "Working…"; err.replaceChildren();
    try { const r = await api(`/api/actions/${name}`, { body: clean(data) }); close(); toast(r.message || "Done.");
      if (r.token) return showToken(r);   // keep the one-time token on screen until the user confirms
      if (r.entity && r.id && META.entities[r.entity]) go(`#/doc/${r.entity}/${r.id}`); else route();
    } catch (e) { busy.textContent = ""; err.replaceChildren(h("div", { class: "err" }, e.message)); }
  };
  form.addEventListener("submit", submit);
  $modal.replaceChildren(h("div", { class: "overlay", onmousedown: e => { if (e.target.classList.contains("overlay")) close(); } },
    h("div", { class: "modal" }, h("header", {}, h("h2", {}, a.title), a.human_only ? h("span", { class: "chip warn" }, "human only") : null, h("button", { class: "btn small", onclick: close }, "✕")),
      h("div", { class: "desc" }, a.description), form, err,
      h("footer", {}, busy, h("button", { class: "btn", onclick: close }, "Cancel"), h("button", { class: "btn primary", onclick: submit }, preset && preset.decision === "reject" ? "Reject" : "Save / Post")))));
  const first = form.querySelector("input:not([type=checkbox]),select,textarea"); if (first) first.focus();
}
function showToken(r) {
  $modal.replaceChildren(h("div", { class: "overlay" }, h("div", { class: "modal", style: "width:min(640px,100%)" }, h("header", {}, h("h2", {}, "Copy this token now")),
    h("div", { class: "desc" }, "It is shown only once. Paste it into your AI client as the Bearer token for the connector."),
    h("form", {}, h("div", { class: "fld" }, h("input", { type: "text", readOnly: true, value: r.token, onfocus: e => e.target.select() }))),
    h("footer", {}, h("button", { class: "btn primary", onclick: () => { $modal.replaceChildren(); route(); } }, "I have copied it")))));
}

// ───────── assistant ─────────
function assistant() {
  const msgs = h("div", { class: "msgs" }), ta = h("textarea", { placeholder: "e.g. Raise a PR for 20 oil filters for Maintenance, budget B-MNT-SPARES, needed in 60 days" });
  const draw = () => { msgs.replaceChildren(...(chat.length ? chat : [{ role: "assistant", content: "I can run this ERP for you: create requisitions, RFQs, orders, receipts and invoices, or answer questions from the reports. I prepare and submit; approvals stay with people." }]).map(mm =>
    h("div", { class: "msg " + (mm.role === "user" ? "user" : "bot") }, (mm.steps || []).map(s => h("div", { class: "step" + (s.ok ? "" : " bad") }, `${s.ok ? "✓" : "✗"} ${s.tool}: ${s.summary}`)), mm.content,
      (mm.docs || []).map(d => h("div", {}, h("a", { onclick: () => go(`#/doc/${d.entity}/${d.id}`) }, "Open " + d.no)))))); msgs.scrollTop = msgs.scrollHeight; };
  const send = async ev => { ev.preventDefault(); const text = ta.value.trim(); if (!text) return; ta.value = ""; chat.push({ role: "user", content: text }); chat.push({ role: "assistant", content: "Working…", pending: true }); draw();
    try { const r = await api("/api/assistant", { body: { messages: chat.filter(c => !c.pending).map(c => ({ role: c.role, content: c.content })) } }); chat.pop(); chat.push({ role: "assistant", content: r.reply, steps: r.steps, docs: r.docs }); }
    catch (e) { chat.pop(); chat.push({ role: "assistant", content: e.message }); }
    draw(); refreshBadge(); };
  ta.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) send(e); });
  draw();
  return h("aside", { class: "assist" }, h("header", {}, "AI Assistant", h("span", { class: "chip mute" }, "prepare & submit only"), h("div", { style: "flex:1" }), h("button", { class: "btn small", onclick: () => { assistOpen = false; route(); } }, "✕")),
    msgs, h("form", { onsubmit: send }, ta, h("button", { class: "btn primary" }, "Send")));
}

// ───────── routing ─────────
function route() {
  if (!META) return;
  clearTimeout(liveTimer);
  const [path, qs] = (location.hash.slice(2) || "home").split("?"), parts = path.split("/"), params = new URLSearchParams(qs || "");
  $modal.replaceChildren();
  const fail = e => shell(h("div", { class: "empty" }, e.message));
  if (parts[0] === "list") viewList(parts[1], params).catch(fail);
  else if (parts[0] === "doc") viewDoc(parts[1], parts[2]).catch(fail);
  else if (parts[0] === "report") viewReport(parts[1]).catch(fail);
  else if (parts[0] === "inbox") viewInbox().catch(fail);
  else if (parts[0] === "tree") viewTree().catch(fail);
  else viewHome();
}
async function boot() {
  try { document.documentElement.dataset.theme = localStorage.getItem("jmeta_theme") || "light"; } catch { }
  if (!store.token) return renderLogin();
  try { META = await api("/api/meta"); } catch { return; }
  document.title = `${META.app.name} – ${META.app.company}`;
  route();
}
window.addEventListener("hashchange", route);
window.addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); const c = document.getElementById("cmd"); if (c) c.focus(); }
  if (e.key === "Escape") $modal.replaceChildren(); });
boot();
