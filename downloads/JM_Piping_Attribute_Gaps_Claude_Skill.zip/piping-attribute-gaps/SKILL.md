---
name: piping-attribute-gaps
description: Fills missing technical attributes in the Piping Materials Cataloguing Template by Jitesh Mehta (version 2.3 or later). Use when the user attaches that Excel workbook and asks to fill, complete or look up the attribute gaps, missing attributes or AI findings, or to find the specification of spares from their manufacturer part numbers.
---

# Piping attribute gaps

Developed by Jitesh Mehta. (c) 2026 Jitesh Mehta. Free to use and adapt within your own organisation. You may not sell, resell or include this skill, or any adapted version of it, in a paid product or service without written permission. The words "Developed by Jitesh Mehta" and this notice must remain in all copies and all adapted versions.

The user is usually a mechanical engineer or materials cataloguer, not a software engineer. Speak plainly, keep messages short, and never ask them to run code.

The rule that governs everything: **the AI proposes, a person confirms.** A wrong attribute means buying the wrong spare. Never guess a value. A value that is not found stays missing.

## Steps

1. **Find the workbook.** It is the .xlsx file the user attached, normally in `/mnt/user-data/uploads/`. If no workbook is attached, ask the user to attach their Piping Materials Cataloguing Template, saved after loading their Material Master.

2. **List the gaps.** Run:
   `python3 scripts/read_gaps.py "<workbook>"`
   (the scripts folder is inside this skill's folder). It prints the items marked READY FOR AI LOOKUP with their manufacturer, part number and missing attributes.
   - If it prints an `error`, tell the user in one sentence and stop.
   - If it prints a `warning`, pass it on in plain words and stop.
   - If nothing is ready, say so, give the counts, and stop.
   - Look up at most 10 items in one go. Tell the user how many are ready and that you will do the first 10; they can ask for the next 10 afterwards.

3. **Look up each item.** For each item, use web search, then web fetch to open and read the manufacturer's own page for that exact part number: the product page, catalogue or datasheet. Find only the attributes in that item's `missing_attributes`. Rules:
   1. Use the manufacturer's own website first. Only if it has nothing may you use an authorised distributor's page that shows the same part number, and then say so in the remarks.
   2. The part number on the page must be the same part number, ignoring only spaces and hyphens. A similar number is not enough. If you cannot confirm the part number, record nothing for that item.
   3. Never guess. Do not fill a value from memory, from a similar item or from what is usual. If the page does not state the attribute, it stays missing.
   4. The source must be the full web address of the exact page or PDF you read the value from, and you must have actually opened it in this conversation.
   5. Copy each value as the manufacturer states it, with its unit. If the page states something close but not exactly the attribute (for example a pressure rating instead of a pressure class, or a tube size instead of an NPS size), give it and say so in the remarks.
   6. Use each attribute name exactly as it appears in `missing_attributes`.

4. **Write the findings.** Save the findings as a JSON list to `/tmp/findings.json`, one object per value found:
   `{"uic": "...", "attribute": "...", "value": "...", "source_url": "...", "remarks": "..."}`
   Then run:
   `python3 scripts/write_findings.py "<workbook>" /tmp/findings.json "/mnt/user-data/outputs/<original name without .xlsx> with AI findings.xlsx"`
   The script checks every finding and writes only the ones that pass, into empty rows of the AI Findings sheet. It never changes anything else in the workbook. Do not edit the workbook any other way, and never open and re-save it with a spreadsheet library: that would damage its drop down lists and formulas.

5. **Report back, briefly.** Give the user:
   - the workbook link to download;
   - a short table: UIC, attribute, value, source (as a link);
   - what was not found, item by item, in one line each;
   - anything the script rejected, and why;
   - this reminder, in these words: "Every value is UNVERIFIED. Open the workbook, go to AI Findings, open each source web address, check the value against the page, then set Status to CONFIRMED and enter your name, or set it to REJECTED. Only confirmed values count towards completeness."

## If something goes wrong

- If web search or web fetch is not available, tell the user to switch on web search in Claude and try again.
- If the workbook cannot be read, ask the user to open it in Excel, save it, and attach it again.
- If the user needs help, they can contact Jitesh at jitesh@jiteshmehta.in.
