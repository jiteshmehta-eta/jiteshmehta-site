"""Write AI findings onto the AI Findings sheet of the template.

Usage: python write_findings.py WORKBOOK.xlsx FINDINGS.json OUTPUT.xlsx

FINDINGS.json is a list of objects with these keys:
  uic, attribute, value, source_url, remarks   (manufacturer and part_number are filled in
  from the Attribute Gaps sheet). Optional: found_by.

Every finding is checked before it is written:
  - the UIC must be on the Attribute Gaps sheet,
  - the attribute must be one of that item's missing attributes,
  - the value must not be empty,
  - the source must be a full web address,
  - one value per attribute per item.
Rejected findings are listed and never written. Only the AI Findings cells in columns A to I
of empty rows are changed; every other part of the workbook is copied unchanged. The Status
column is left empty, so the sheet shows each value as UNVERIFIED until a person confirms it.
(c) 2026 Jitesh Mehta. Developed by Jitesh Mehta."""
import datetime
import json
import os
import re
import sys
import zipfile
from xml.sax.saxutils import escape

sys.path.insert(0, os.path.dirname(__file__))
from xlsx_parts import read_rows, sheet_part  # noqa: E402

COLS = ["A", "B", "C", "D", "E", "F", "G", "H", "I"]
FIRST, LAST = 6, 2005


def col_index(c):
    n = 0
    for ch in c:
        n = n * 26 + ord(ch) - 64
    return n


def clean(s):
    s = "" if s is None else str(s)
    s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", s).strip()
    return s[:32000]


def inline_cell(ref, style, text):
    s = ' s="%s"' % style if style else ""
    return '<c r="%s"%s t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (ref, s, escape(text))


def number_cell(ref, style, num):
    s = ' s="%s"' % style if style else ""
    return '<c r="%s"%s><v>%s</v></c>' % (ref, s, num)


def put_cells(row_xml, row, values):
    """Replace or insert cells A..I in one <row> element, keeping cell order and styles."""
    m = re.match(r"(<row\b[^>]*?)(/>|>)(.*?)(</row>)?$", row_xml, re.S)
    head, close, body = m.group(1), m.group(2), m.group(3) or ""
    cells = re.findall(r'<c r="[A-Z]+\d+"[^>]*?(?:/>|>.*?</c>)', body, re.S)
    by_col = {}
    for c in cells:
        col = re.match(r'<c r="([A-Z]+)', c).group(1)
        by_col[col] = c
    for col, (kind, val) in values.items():
        old = by_col.get(col, "")
        st = re.search(r'\bs="(\d+)"', old)
        st = st.group(1) if st else ""
        ref = "%s%d" % (col, row)
        by_col[col] = number_cell(ref, st, val) if kind == "n" else inline_cell(ref, st, val)
    ordered = sorted(by_col.items(), key=lambda kv: col_index(kv[0]))
    head = re.sub(r'\sspans="[^"]*"', "", head)
    return head + ">" + "".join(c for _, c in ordered) + "</row>"


def main():
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(2)
    src, fpath, dst = sys.argv[1:4]
    if os.path.abspath(src) == os.path.abspath(dst):
        print("Write to a new file name, not over the original.")
        sys.exit(2)
    findings = json.load(open(fpath, encoding="utf-8"))
    z = zipfile.ZipFile(src)
    gaps_p = sheet_part(z, "Attribute Gaps")
    af_p = sheet_part(z, "AI Findings")
    if not gaps_p or not af_p:
        print("This workbook has no Attribute Gaps or AI Findings sheet. Use version 2.3 or later.")
        sys.exit(1)

    gaps = read_rows(z, gaps_p, 6, set("ACEFK"))
    items = {}
    for g in gaps.values():
        if g.get("A", "").strip() and g.get("C", "").strip():
            items[g["C"].strip()] = {
                "manufacturer": g.get("E", ""), "part_number": g.get("F", ""),
                "missing": {a.strip().lower(): a.strip() for a in g.get("K", "").split(";") if a.strip()},
            }

    accepted, rejected, seen = [], [], set()
    for f in findings:
        uic = clean(f.get("uic"))
        attr = clean(f.get("attribute"))
        val = clean(f.get("value"))
        src_url = clean(f.get("source_url"))
        why = ""
        if uic not in items:
            why = "UIC is not on the Attribute Gaps sheet"
        elif attr.lower() not in items[uic]["missing"]:
            why = "attribute is not on the missing list for this item"
        elif not val:
            why = "no value"
        elif not re.match(r"^https?://\S+\.\S+", src_url):
            why = "no full source web address"
        elif (uic, attr.lower()) in seen:
            why = "second value for the same attribute"
        if why:
            rejected.append({"uic": uic, "attribute": attr, "value": val, "reason": why})
            continue
        seen.add((uic, attr.lower()))
        it = items[uic]
        accepted.append([uic, it["manufacturer"], it["part_number"], it["missing"][attr.lower()], val,
                         src_url, clean(f.get("found_by")) or "Claude with web search (skill)",
                         None, clean(f.get("remarks"))])

    xml = z.read(af_p).decode("utf-8")
    existing = read_rows(z, af_p, FIRST, {"A", "D", "E"})
    free = [r for r in range(FIRST, LAST + 1) if not existing.get(r, {}).get("A", "").strip()
            and not existing.get(r, {}).get("E", "").strip()]
    if len(accepted) > len(free):
        print("The AI Findings sheet is full. Nothing was written.")
        sys.exit(1)
    today = (datetime.date.today() - datetime.date(1899, 12, 30)).days

    rows_xml = {int(m.group(1)): m for m in re.finditer(r'<row r="(\d+)"[^>]*?(?:/>|>.*?</row>)', xml, re.S)}
    edits = {}
    for vals, row in zip(accepted, free):
        values = {}
        for col, v in zip(COLS, vals):
            values[col] = ("n", today) if col == "H" else ("s", v)
        if row in rows_xml:
            edits[row] = put_cells(rows_xml[row].group(0), row, values)
        else:
            edits[row] = put_cells('<row r="%d">' % row, row, values)

    # rebuild sheetData with the edited rows, in row order
    def repl(m):
        r = int(m.group(1))
        return edits.pop(r) if r in edits else m.group(0)
    xml = re.sub(r'<row r="(\d+)"[^>]*?(?:/>|>.*?</row>)', repl, xml, flags=re.S)
    if edits:  # rows that did not exist yet
        sd = re.search(r"<sheetData>(.*?)</sheetData>|<sheetData/>", xml, re.S)
        rows = re.findall(r'<row r="(\d+)"[^>]*?(?:/>|>.*?</row>)', sd.group(0), re.S)
        allrows = {int(m.group(1)): m.group(0) for m in re.finditer(r'<row r="(\d+)"[^>]*?(?:/>|>.*?</row>)', sd.group(0), re.S)}
        allrows.update(edits)
        new_sd = "<sheetData>" + "".join(allrows[k] for k in sorted(allrows)) + "</sheetData>"
        xml = xml[:sd.start()] + new_sd + xml[sd.end():]

    wb = z.read("xl/workbook.xml").decode("utf-8")
    if "<calcPr" in wb:
        wb = re.sub(r"<calcPr\b([^>]*?)/>", lambda m: "<calcPr" + re.sub(r'\s*fullCalcOnLoad="[^"]*"', "", m.group(1)) + ' fullCalcOnLoad="1"/>', wb, count=1)
    else:
        wb = wb.replace("</workbook>", '<calcPr fullCalcOnLoad="1"/></workbook>')

    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as out:
        for info in z.infolist():
            data = z.read(info.filename)
            if info.filename == af_p:
                data = xml.encode("utf-8")
            elif info.filename == "xl/workbook.xml":
                data = wb.encode("utf-8")
            zi = zipfile.ZipInfo(info.filename, date_time=info.date_time)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = info.external_attr
            out.writestr(zi, data)

    print(json.dumps({"written": len(accepted), "rejected": rejected,
                      "rows_used": free[:len(accepted)], "output": dst}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
