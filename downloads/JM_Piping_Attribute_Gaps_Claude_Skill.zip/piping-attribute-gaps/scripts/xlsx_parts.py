"""Shared helpers: find a sheet's XML part and read cell values from an .xlsx
without any third party library and without rewriting the workbook.
(c) 2026 Jitesh Mehta. Developed by Jitesh Mehta."""
import re
import zipfile
from html import unescape

MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"


def sheet_part(z, sheet_name):
    wb = z.read("xl/workbook.xml").decode("utf-8")
    rels = z.read("xl/_rels/workbook.xml.rels").decode("utf-8")
    rid = None
    for m in re.finditer(r"<sheet\b[^>]*>", wb):
        tag = m.group(0)
        name = re.search(r'\bname="([^"]*)"', tag)
        if name and unescape(name.group(1)) == sheet_name:
            rid = re.search(r'\br:id="([^"]+)"', tag).group(1)
            break
    if rid is None:
        return None
    for m in re.finditer(r"<Relationship\b[^>]*>", rels):
        tag = m.group(0)
        if re.search(r'\bId="%s"' % re.escape(rid), tag):
            target = re.search(r'\bTarget="([^"]+)"', tag).group(1)
            target = target.lstrip("/")
            return target if target.startswith("xl/") else "xl/" + target
    return None


def shared_strings(z):
    if "xl/sharedStrings.xml" not in z.namelist():
        return []
    xml = z.read("xl/sharedStrings.xml").decode("utf-8")
    out = []
    for si in re.finditer(r"<si>(.*?)</si>", xml, re.S):
        out.append(unescape("".join(re.findall(r"<t[^>]*>(.*?)</t>", si.group(1), re.S))))
    return out


CELL = re.compile(r'<c r="([A-Z]+)(\d+)"([^>]*?)(?:/>|>(.*?)</c>)', re.S)


def cell_text(attrs, body, sst):
    t = re.search(r'\bt="([^"]+)"', attrs)
    t = t.group(1) if t else "n"
    if t == "inlineStr":
        return unescape("".join(re.findall(r"<t[^>]*>(.*?)</t>", body or "", re.S)))
    v = re.search(r"<v>(.*?)</v>", body or "", re.S)
    if not v:
        return ""
    v = unescape(v.group(1))
    if t == "s":
        return sst[int(v)]
    if t == "b":
        return "TRUE" if v == "1" else "FALSE"
    if t == "n":
        try:
            f = float(v)
            return str(int(f)) if f == int(f) else v
        except ValueError:
            return v
    return v


def read_rows(z, part, first_row, cols):
    """Return {row: {col: text}} for rows >= first_row, only the columns asked for."""
    sst = shared_strings(z)
    xml = z.read(part).decode("utf-8")
    rows = {}
    for m in CELL.finditer(xml):
        col, row = m.group(1), int(m.group(2))
        if row < first_row or col not in cols:
            continue
        rows.setdefault(row, {})[col] = cell_text(m.group(3), m.group(4), sst)
    return rows
