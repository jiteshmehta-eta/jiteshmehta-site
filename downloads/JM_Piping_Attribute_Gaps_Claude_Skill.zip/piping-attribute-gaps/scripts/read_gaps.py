"""List the items on the Attribute Gaps sheet that are ready for AI lookup.

Usage: python read_gaps.py WORKBOOK.xlsx [--all]
Prints JSON: {"ready": [...], "counts": {...}, "warning": "..."}
Reads only. The workbook is not changed.
(c) 2026 Jitesh Mehta. Developed by Jitesh Mehta."""
import json
import sys
import zipfile

sys.path.insert(0, __import__("os").path.dirname(__file__))
from xlsx_parts import read_rows, sheet_part  # noqa: E402


def pct(v):
    try:
        return "%d%%" % round(float(v) * 100)
    except ValueError:
        return v


def main():
    if len(sys.argv) < 2:
        print("Usage: python read_gaps.py WORKBOOK.xlsx [--all]")
        sys.exit(2)
    path = sys.argv[1]
    show_all = "--all" in sys.argv
    z = zipfile.ZipFile(path)
    need = ["Attribute Gaps", "AI Findings", "Material Master"]
    parts = {n: sheet_part(z, n) for n in need}
    missing = [n for n, p in parts.items() if not p]
    if missing:
        print(json.dumps({"error": "This is not version 2.3 or later of the Piping Materials "
                          "Cataloguing Template. Missing sheet(s): " + ", ".join(missing)}))
        sys.exit(1)

    mm = read_rows(z, parts["Material Master"], 6, {"A"})
    loaded = sum(1 for r in mm.values() if r.get("A", "").strip())
    gaps = read_rows(z, parts["Attribute Gaps"], 6, set("ACDEFGHIJKL"))
    items, counts = [], {"incomplete": 0, "ready": 0, "awaiting": 0, "no_part_number": 0}
    for row in sorted(gaps):
        g = gaps[row]
        if not g.get("A", "").strip():
            continue
        counts["incomplete"] += 1
        status = g.get("L", "")
        if status.startswith("AI VALUES AWAITING"):
            counts["awaiting"] += 1
        elif status.startswith("NO PART NUMBER"):
            counts["no_part_number"] += 1
        elif status == "READY FOR AI LOOKUP":
            counts["ready"] += 1
        if status != "READY FOR AI LOOKUP" and not show_all:
            continue
        items.append({
            "uic": g.get("C", ""), "short_text": g.get("D", ""), "manufacturer": g.get("E", ""),
            "part_number": g.get("F", ""), "item_type": g.get("G", ""),
            "completeness": pct(g.get("J", "")), "status": status,
            "missing_attributes": [a.strip() for a in g.get("K", "").split(";") if a.strip()],
        })
    out = {"material_master_rows": loaded, "counts": counts, "ready": items}
    head = read_rows(z, parts["Attribute Gaps"], 3, {"B"}).get(3, {})
    if loaded and head.get("B", "") != str(loaded):
        out["warning"] = ("The Material Master has rows but the Attribute Gaps sheet has no saved "
                          "results. Ask the user to open the workbook in Excel, wait for it to "
                          "calculate, save it and attach it again.")
    print(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
