﻿<#
JM Attribute Lookup, companion tool for the Piping Materials Cataloguing Template.
(c) 2026 Jitesh Mehta. Developed by Jitesh Mehta. Free to use and adapt within your own
organisation. You may not sell, resell or include this tool, or any adapted version of it, in a
paid product or service without written permission. The words "Developed by Jitesh Mehta" and
this notice must remain in all copies and all adapted versions. Provided as is, for guidance only.

What it does
  Reads the Attribute Gaps sheet, asks Claude (with web search) to find the missing attributes
  of each item on the manufacturer's website, and writes what it finds onto the AI Findings
  sheet with the web address of the source. Every value it writes is UNVERIFIED until a person
  opens the source, checks it and sets Status to CONFIRMED. Nothing is guessed: an attribute
  that is not found stays on the missing list.

Its own checks, applied before anything is written
  1. The part number must be confirmed on the page, or the item's findings are discarded.
  2. The attribute must be one of the missing attributes named for that item.
  3. The source web address must be one the web search actually returned in this run.
  4. A value must not be empty.

Your key
  Uses your own Anthropic API key. It is read from the ANTHROPIC_API_KEY environment variable
  if set, otherwise you are asked for it each time. It is never written to the workbook or to disk.

Needs Windows, Microsoft Excel and an internet connection. Close the workbook in Excel first.
#>
param(
    [string]$Workbook = '',
    [int]$MaxItems = 10,
    [string]$Model = 'claude-opus-5-5',
    [string]$Effort = 'medium',
    [int]$MaxSearches = 5,
    [string]$ResponsesDir = ''      # testing only: read saved replies instead of calling the API
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ToolName = 'JM Attribute Lookup 1.0'

function Say([string]$t) { Write-Host $t }

# ------------------------------------------------------------------ choose the workbook
if (-not $Workbook) {
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = 'Choose the Piping Materials Cataloguing Template'
    $dlg.Filter = 'Excel workbook (*.xlsx)|*.xlsx'
    if ($dlg.ShowDialog() -ne 'OK') { Say 'No workbook chosen. Nothing was changed.'; exit 1 }
    $Workbook = $dlg.FileName
}
$Workbook = (Resolve-Path $Workbook).Path
try { $fs = [IO.File]::Open($Workbook, 'Open', 'ReadWrite', 'None'); $fs.Close() }
catch { Say "The workbook is open in Excel or in use. Close it and run the tool again.`n$Workbook"; exit 1 }

# ------------------------------------------------------------------ the key
$ApiKey = $env:ANTHROPIC_API_KEY
if (-not $ResponsesDir -and -not $ApiKey) {
    $sec = Read-Host 'Paste your Anthropic API key and press Enter (it is not saved)' -AsSecureString
    $ApiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
    if (-not $ApiKey) { Say 'No key entered. Nothing was changed.'; exit 1 }
}

# ------------------------------------------------------------------ helpers
function Norm-Url([string]$u) {
    if (-not $u) { return '' }
    $u = $u.Trim().ToLowerInvariant()
    $i = $u.IndexOf('#'); if ($i -ge 0) { $u = $u.Substring(0, $i) }
    $u = $u -replace '^https?://', '' -replace '^www\.', ''
    return $u.TrimEnd('/')
}
function Norm-Pn([string]$p) { return ($p -replace '[\s\-\./_]', '').ToUpperInvariant() }

function Call-Claude($body) {
    $json = $body | ConvertTo-Json -Depth 30 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $headers = @{ 'x-api-key' = $ApiKey; 'anthropic-version' = '2023-06-01'; 'anthropic-beta' = 'server-side-fallback-2026-07-01' }
    for ($try = 1; $try -le 3; $try++) {
        try {
            $resp = Invoke-WebRequest -Uri 'https://api.anthropic.com/v1/messages' -Method Post -Headers $headers `
                -ContentType 'application/json; charset=utf-8' -Body $bytes -UseBasicParsing -TimeoutSec 300
            $text = [Text.Encoding]::UTF8.GetString($resp.RawContentStream.ToArray())
            return $text | ConvertFrom-Json
        } catch {
            $code = 0; try { $code = [int]$_.Exception.Response.StatusCode } catch {}
            if ($code -eq 401) { throw 'The API key was refused. Check it and run the tool again.' }
            if (($code -eq 429 -or $code -ge 500) -and $try -lt 3) { Start-Sleep -Seconds (20 * $try); continue }
            throw "The AI service returned an error ($code): $($_.Exception.Message)"
        }
    }
}

function Ask-Item($item) {
    $prompt = @"
You are helping a materials cataloguer complete missing technical attributes for a piping spare.

Item
UIC: $($item.UIC)
Short text: $($item.Text)
Manufacturer: $($item.Mfr)
Part number: $($item.PN)
Item type: $($item.Type)
Missing attributes: $($item.Missing -join '; ')

Search the web, then use web fetch to open and read the manufacturer's own page for this exact part number: the product page, catalogue or datasheet. Find only the missing attributes listed above.

Rules you must follow:
1. Use the manufacturer's own website first. Only if it has nothing may you use an authorised distributor's page that shows the same part number, and then say so in remarks.
2. The part number on the page must be the same part number, ignoring only spaces and hyphens. A similar number is not enough.
3. Never guess. Do not fill a value from memory, from a similar item or from what is usual. If the source does not state the attribute, put it under not_found.
4. Give the full web address of the exact page where you read each value.
5. Copy each value as the manufacturer states it, with its unit. If the page states something close to but not exactly the attribute (for example a pressure rating instead of a pressure class), give it and say so in remarks.
6. Write each attribute name exactly as it appears in Missing attributes.

When you have finished searching, reply with one JSON object and nothing else, in this form:
{"part_number_confirmed": true, "part_number_page": "full web address where the part number appears",
 "findings": [{"attribute": "...", "value": "...", "source_url": "...", "remarks": "..."}],
 "not_found": [{"attribute": "...", "where_looked": "..."}]}
"@
    $messages = @(@{ role = 'user'; content = $prompt })
    $all = @()
    $usage = @{ in = 0; out = 0; searches = 0 }
    for ($turn = 1; $turn -le 4; $turn++) {
        if ($ResponsesDir) {
            $f = Join-Path $ResponsesDir ($item.UIC + '.json')
            if (-not (Test-Path $f)) { throw "No saved reply for $($item.UIC)" }
            $r = Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json
        } else {
            $r = Call-Claude @{
                model = $Model; max_tokens = 16000; messages = $messages
                output_config = @{ effort = $Effort }
                fallbacks = 'default'
                tools = @(
                    @{ type = 'web_search_20260209'; name = 'web_search'; max_uses = $MaxSearches },
                    @{ type = 'web_fetch_20260209'; name = 'web_fetch'; max_uses = $MaxSearches }
                )
            }
        }
        $all += @($r.content)
        if ($r.usage) {
            $usage.in += [int]$r.usage.input_tokens; $usage.out += [int]$r.usage.output_tokens
            if ($r.usage.server_tool_use) { $usage.searches += [int]$r.usage.server_tool_use.web_search_requests + [int]$r.usage.server_tool_use.web_fetch_requests }
        }
        if ($r.stop_reason -eq 'refusal') { throw 'The AI declined this request.' }
        if ($r.stop_reason -ne 'pause_turn') { break }
        $messages += @{ role = 'assistant'; content = $r.content }
    }
    # every web address the search really returned, plus any it cited
    $seen = @{}
    foreach ($b in $all) {
        if ($b.type -eq 'web_search_tool_result') {
            foreach ($x in @($b.content)) { if ($x.url) { $seen[(Norm-Url $x.url)] = $x.url } }
        }
        if ($b.type -eq 'web_fetch_tool_result' -and $b.content.url) { $seen[(Norm-Url $b.content.url)] = $b.content.url }
        if ($b.type -eq 'text' -and $b.citations) { foreach ($c in $b.citations) { if ($c.url) { $seen[(Norm-Url $c.url)] = $c.url } } }
    }
    $text = (($all | Where-Object { $_.type -eq 'text' } | ForEach-Object { $_.text }) -join "`n")
    $a = $text.IndexOf('{'); $z = $text.LastIndexOf('}')
    $answer = $null
    if ($a -ge 0 -and $z -gt $a) { try { $answer = $text.Substring($a, $z - $a + 1) | ConvertFrom-Json } catch {} }
    return @{ Answer = $answer; Seen = $seen; Usage = $usage; Raw = $text }
}

# ------------------------------------------------------------------ read the gaps
$xl = New-Object -ComObject Excel.Application
$xl.Visible = $false; $xl.DisplayAlerts = $false
$log = New-Object System.Collections.ArrayList
$written = 0; $rejected = 0; $notFound = 0
try {
    Say "Opening $Workbook"
    $wb = $xl.Workbooks.Open($Workbook)
    $names = @(); foreach ($s in $wb.Sheets) { $names += $s.Name }
    foreach ($need in 'Attribute Gaps', 'AI Findings', 'Attribute Rules') {
        if ($names -notcontains $need) { throw "This workbook has no '$need' sheet. Use version 2.3 or later of the template." }
    }
    $xl.CalculateFull()
    $ag = $wb.Sheets.Item('Attribute Gaps')
    $items = @()
    $r = 6
    while ($true) {
        $v = $ag.Range("A${r}:L$r").Value2
        if ([string]$v[1, 1] -eq '') { break }
        if ([string]$v[1, 12] -eq 'READY FOR AI LOOKUP' -and [string]$v[1, 11] -ne '') {
            $items += [pscustomobject]@{
                UIC = [string]$v[1, 3]; Text = [string]$v[1, 4]; Mfr = [string]$v[1, 5]; PN = [string]$v[1, 6]
                Type = [string]$v[1, 7]; Missing = @(([string]$v[1, 11]) -split ';\s*' | Where-Object { $_ })
            }
        }
        $r++
    }
    Say ("{0} item(s) are ready for AI lookup. This run will look up {1}." -f $items.Count, [Math]::Min($items.Count, $MaxItems))
    if ($items.Count -eq 0) { Say 'Nothing to look up. Nothing was changed.'; $wb.Close($false); return }
    $items = @($items | Select-Object -First $MaxItems)

    $af = $wb.Sheets.Item('AI Findings')
    $next = 6; while ([string]$af.Cells.Item($next, 1).Value2 -ne '') { $next++ }
    $today = (Get-Date).ToString('dd MMM yyyy', [Globalization.CultureInfo]::GetCultureInfo('en-GB'))
    $foundBy = "$ToolName, $Model"
    $totIn = 0; $totOut = 0; $totSearch = 0

    foreach ($it in $items) {
        Say ("Looking up {0}  {1} {2} ..." -f $it.UIC, $it.Mfr, $it.PN)
        try { $res = Ask-Item $it } catch { Say "   Skipped: $_"; [void]$log.Add([pscustomobject]@{ UIC = $it.UIC; Attribute = ''; Result = 'ERROR'; Value = ''; Source = ''; Reason = "$_" }); continue }
        $totIn += $res.Usage.in; $totOut += $res.Usage.out; $totSearch += $res.Usage.searches
        $ans = $res.Answer
        if (-not $ans) {
            Say '   The reply could not be read. Nothing written for this item.'
            [void]$log.Add([pscustomobject]@{ UIC = $it.UIC; Attribute = ''; Result = 'NO READABLE REPLY'; Value = ''; Source = ''; Reason = $res.Raw.Substring(0, [Math]::Min(300, $res.Raw.Length)) })
            continue
        }
        if (-not $ans.part_number_confirmed) {
            Say '   Part number not confirmed on any page. Nothing written for this item.'
            [void]$log.Add([pscustomobject]@{ UIC = $it.UIC; Attribute = ''; Result = 'PART NUMBER NOT CONFIRMED'; Value = ''; Source = [string]$ans.part_number_page; Reason = '' })
            continue
        }
        $missingSet = @{}; foreach ($m in $it.Missing) { $missingSet[$m.Trim().ToLowerInvariant()] = $m.Trim() }
        $done = @{}
        foreach ($f in @($ans.findings)) {
            if (-not $f) { continue }
            $attr = ([string]$f.attribute).Trim(); $val = ([string]$f.value).Trim(); $src = ([string]$f.source_url).Trim()
            $why = ''
            if (-not $missingSet.ContainsKey($attr.ToLowerInvariant())) { $why = 'attribute not on the missing list for this item' }
            elseif ($val -eq '') { $why = 'no value' }
            elseif ($src -notmatch '^https?://') { $why = 'no source web address' }
            elseif (-not $res.Seen.ContainsKey((Norm-Url $src))) { $why = 'source web address was not returned by the search in this run' }
            elseif ($done.ContainsKey($attr.ToLowerInvariant())) { $why = 'second value for the same attribute' }
            if ($why) {
                $rejected++
                [void]$log.Add([pscustomobject]@{ UIC = $it.UIC; Attribute = $attr; Result = 'REJECTED BY TOOL'; Value = $val; Source = $src; Reason = $why })
                continue
            }
            $attr = $missingSet[$attr.ToLowerInvariant()]; $done[$attr.ToLowerInvariant()] = 1
            $row = @($it.UIC, $it.Mfr, $it.PN, $attr, $val, $src, $foundBy, $today, ([string]$f.remarks).Trim())
            for ($c = 0; $c -lt 9; $c++) { $af.Cells.Item($next, $c + 1).Value2 = [string]$row[$c] }
            $next++; $written++
            [void]$log.Add([pscustomobject]@{ UIC = $it.UIC; Attribute = $attr; Result = 'WRITTEN, UNVERIFIED'; Value = $val; Source = $src; Reason = ([string]$f.remarks).Trim() })
        }
        foreach ($m in $it.Missing) {
            if (-not $done.ContainsKey($m.ToLowerInvariant())) {
                $notFound++
                $where = ''; foreach ($n in @($ans.not_found)) { if ($n -and ([string]$n.attribute).Trim().ToLowerInvariant() -eq $m.ToLowerInvariant()) { $where = [string]$n.where_looked } }
                [void]$log.Add([pscustomobject]@{ UIC = $it.UIC; Attribute = $m; Result = 'NOT FOUND, STILL MISSING'; Value = ''; Source = ''; Reason = $where })
            }
        }
        Say ("   {0} value(s) written, still missing: {1}" -f $done.Count, ($it.Missing.Count - $done.Count))
    }
    $xl.CalculateFull()
    $wb.Save()
    $wb.Close($false)
} finally {
    $xl.Quit(); [void][Runtime.InteropServices.Marshal]::ReleaseComObject($xl)
    $ApiKey = $null
}

$stamp = (Get-Date).ToString('yyyy-MM-dd HHmm')
$logFile = Join-Path (Split-Path $Workbook) "AI lookup log $stamp.csv"
$log | Export-Csv -Path $logFile -NoTypeInformation -Encoding UTF8
Say ''
Say "Done. $written value(s) written to the AI Findings sheet, all UNVERIFIED."
Say "$rejected answer(s) rejected by the tool's checks. $notFound attribute(s) not found and still missing."
Say "Web searches and page reads used: $totSearch. Tokens: $totIn in, $totOut out."
Say "Log: $logFile"
Say 'Next: open the workbook, go to AI Findings, open each source web address and set Status to CONFIRMED or REJECTED.'
