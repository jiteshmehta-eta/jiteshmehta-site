@echo off
rem JM Attribute Lookup 1.0. Double click to run. (c) 2026 Jitesh Mehta. Developed by Jitesh Mehta.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0program\JM_Attribute_Lookup.ps1" %*
echo.
pause
